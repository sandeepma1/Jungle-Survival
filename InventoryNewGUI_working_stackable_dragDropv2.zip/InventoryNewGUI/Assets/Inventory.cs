﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class Inventory : MonoBehaviour
{
		public List<GameObject> Slots = new List<GameObject> ();
		public List<Item>Items = new List<Item> ();
		public GameObject slots;
		ItemDatabase database;
		int x = -115;
		int y = 130;
		public GameObject toolTip;
		public GameObject draggedItemGameObject;
		public bool draggingItem = false;
		public Item draggedItem;
		public int indexOfDraggedItems;

		void Start ()
		{
				int slotAmount = 0;
				database = GameObject.FindGameObjectWithTag ("ItemDatabase").GetComponent<ItemDatabase> ();
		
				for (int i=1; i<6; i++) {
						for (int j=1; j<6; j++) {
								GameObject slot = (GameObject)Instantiate (slots);
								slot.GetComponent<SlotScript> ().slotNumber = slotAmount;
								Slots.Add (slot);
								Items.Add (new Item ());
								slot.transform.parent = this.gameObject.transform;
								slot.name = "Slot" + i + "." + j;
								slot.GetComponent<RectTransform> ().localPosition = new Vector3 (x, y, 0);
								x = x + 55;
								if (j == 5) {
										x = -115;
										y = y - 55;
								}
								slotAmount ++;
						}
				}
				addItem (3);
				/*addItem (1);
				addItem (2);
				addItem (3);
				addItem (3);*/
		}
		
		void Update ()
		{
				if (draggingItem) {
						Vector3 pos = (Input.mousePosition - GameObject.FindGameObjectWithTag ("Canvas").GetComponent<RectTransform> ().localPosition);
						draggedItemGameObject.GetComponent<RectTransform> ().localPosition = new Vector3 (pos.x + 15, pos.y - 15, pos.z);
				}
				if (Input.GetMouseButtonDown (1)) {
						addItem (Random.Range (1, 5));
						//addItem (3);
				}

		}

		public void showDraggedItem (Item item, int slotNumber)
		{
				indexOfDraggedItems = slotNumber;
				closeTooltip ();
				draggedItemGameObject.SetActive (true);
				draggedItem = item;
				draggingItem = true;
				draggedItemGameObject.GetComponent<Image> ().sprite = item.itemIcon;
		}
		public void closeTooltip ()
		{
				toolTip.SetActive (false);
		
		}
		public void closeDraggedItem ()
		{
				draggingItem = false;
				draggedItemGameObject.SetActive (false);
		}

		public void showTooltip (Vector3 toolPosition, Item item)
		{
				//toolTip.SetActive (true);
				toolTip.GetComponent<RectTransform> ().localPosition = new Vector3 (toolPosition.x + 100, toolPosition.y, toolPosition.z);
		
				toolTip.transform.GetChild (0).GetComponent<Text> ().text = item.itemName;
				toolTip.transform.GetChild (1).GetComponent<Text> ().text = item.itemDesc;
		}
		
		void addItem (int id)
		{
				print ("Items Added with index: " + id);
				for (int k=0; k<database.items.Count; k++) {
						if (database.items [k].itemID == id) {
								Item item = database.items [k];								
								if (database.items [k].isItemStackable == true) {
										checkIfItemExists (id, item);
										break;
								} else {
										addItemAtEmptySlot (item);
								}								
						}
				}
		}
		public void checkIfItemExists (int itemID, Item item)
		{				
				for (int i=0; i<Items.Count; i++) {
						if (Items [i].itemID == itemID) {
								Items [i].itemValue = Items [i].itemValue + 1;
								break;
						} else if (i == Items.Count - 1) {
								addItemAtEmptySlot (item);
						}
				}
		}
		void addItemAtEmptySlot (Item item)
		{
				for (int i = 0; i<Items.Count; i++) {
						if (Items [i].itemName == null) {
								Items [i] = item;
								Items [i].itemValue = 1;
								break;
						}
				}
		}
		
}
