﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ItemDatabase : MonoBehaviour
{
		public List<Item> items = new List<Item> ();

		// Use this for initialization
		void Start ()
		{
				items.Add (new Item ("log", 0, "some log", 10, 10, 1, Item.ItemType.Chest, true, 10));
				items.Add (new Item ("flint", 1, "some flint", 10, 10, 1, Item.ItemType.Chest, true, 15));
				items.Add (new Item ("stick", 2, "some stick", 10, 10, 1, Item.ItemType.Chest, true, 15));
				items.Add (new Item ("berry", 3, "eat berries", 10, 10, 1, Item.ItemType.Consumable, true, 15));
				items.Add (new Item ("log", 4, "some log", 10, 10, 1, Item.ItemType.Chest, true, 10));
				items.Add (new Item ("axe", 10, "some axe", 10, 10, 1, Item.ItemType.Weapon, false, 0));
				items.Add (new Item ("pickaxe", 11, "some pickaxe", 10, 10, 1, Item.ItemType.Weapon, false, 0));
				items.Add (new Item ("spear", 12, "some spear", 10, 10, 1, Item.ItemType.Weapon, false, 0));
				items.Add (new Item ("campfire", 13, "eat berries", 10, 10, 1, Item.ItemType.Build, false, 0));
		}
	
		
}
